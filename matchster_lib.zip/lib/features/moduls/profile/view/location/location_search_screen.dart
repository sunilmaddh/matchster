import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:matchster/core/constants/app_colors.dart';
import 'package:matchster/core/utils/extentions.dart';
import 'package:matchster/core/widgets/bar/custom_app_bar.dart';
import 'package:matchster/core/widgets/fields/common_text.dart';
import 'package:matchster/features/moduls/profile/controller/profile_controller.dart';

class LocationSearchScreen extends StatefulWidget {
  final String? title;
  final String? selectedValue;
  final String? type;
  final String? country;
  final String? state;

  const LocationSearchScreen({
    super.key,
    this.title,
    this.selectedValue,
    this.type,
    this.country,
    this.state,
  });

  @override
  State<LocationSearchScreen> createState() => _LocationSearchScreenState();
}

class _LocationSearchScreenState extends State<LocationSearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  final _controller = Get.find<ProfileController>();

  @override
  void initState() {
    super.initState();
    _loadInitialData();
  }

  void _loadInitialData() {
    if (widget.type == 'country') {
      _controller.getCountry();
    } else if (widget.type == 'state' && widget.country != null) {
      _controller.getState(country: widget.country!);
    } else if (widget.type == 'city' && widget.country != null && widget.state != null) {
      _controller.getCity(country: widget.country!, state: widget.state!);
    }
  }

  void _onSearchChanged(String query) {
    if (widget.type == 'country') {
      _controller.getCountry(search: query);
    } else if (widget.type == 'state' && widget.country != null) {
      _controller.getState(country: widget.country!, search: query);
    } else if (widget.type == 'city' && widget.country != null && widget.state != null) {
      _controller.getCity(country: widget.country!, state: widget.state!, search: query);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        isCenterTitle: false,
        title: widget.title ?? "Select",
        onTop: () => Get.back(),
      ),
      body: Column(
        children: [
          Padding(
            padding: 15.horizontalPadding + 10.verticalPadding,
            child: TextField(
              controller: _searchController,
              autofocus: true,
              decoration: InputDecoration(
                hintText: "Search ${widget.title?.toLowerCase() ?? 'location'}...",
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20.r),
                ),
              ),
              onChanged: _onSearchChanged,
            ),
          ),
          Expanded(
            child: Obx(() {
              final isLoading = widget.type == 'country'
                  ? _controller.isLoadingCountries.value
                  : widget.type == 'state'
                      ? _controller.isLoadingStates.value
                      : _controller.isLoadingCities.value;

              final items = widget.type == 'country'
                  ? _controller.countryList
                  : widget.type == 'state'
                      ? _controller.stateList
                      : _controller.cityList;

              if (isLoading) {
                return Center(
                  child: CircularProgressIndicator(color: AppColors.primary),
                );
              }

              if (items.isEmpty) {
                return Center(
                  child: CommonText.text(
                    "No results found",
                    fontSize: 16.sp,
                    color: AppColors.blackColor.withAlpha(128),
                  ),
                );
              }

              return ListView.builder(
                itemCount: items.length,
                itemBuilder: (context, index) {
                  final item = items[index];
                  final isSelected = item == widget.selectedValue;
                  return InkWell(
                    onTap: () => Get.back(result: item),
                    child: Container(
                      padding: 15.horizontalPadding + 12.verticalPadding,
                      decoration: BoxDecoration(
                        color: isSelected
                            ? AppColors.primary.withAlpha(26)
                            : AppColors.whiteColor,
                        border: Border(
                          bottom: BorderSide(
                            color: AppColors.commonLightColor,
                          ),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          CommonText.text(
                            item,
                            fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                          ),
                          if (isSelected)
                            Icon(Icons.check, color: AppColors.primary),
                        ],
                      ),
                    ),
                  );
                },
              );
            }),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}
