import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:matchster/core/constants/app_colors.dart';
import 'package:matchster/core/utils/extentions.dart';
import 'package:matchster/core/widgets/bar/custom_app_bar.dart';
import 'package:matchster/core/widgets/bottomsheet/custom_bottomsheet.dart';
import 'package:matchster/core/widgets/buttons/circle_button_widget.dart';
import 'package:matchster/core/widgets/fields/common_text.dart';
import 'package:matchster/core/widgets/fields/custom_form_field.dart';
import 'package:matchster/features/moduls/profile/controller/profile_controller.dart';
import 'package:matchster/features/moduls/profile/helper/profile_helper.dart';
import 'package:matchster/features/moduls/profile/view/location/location_search_screen.dart';

class AddHomeTownScreen extends StatefulWidget {
  const AddHomeTownScreen({super.key});

  @override
  State<AddHomeTownScreen> createState() => _AddHomeTownScreenState();
}

class _AddHomeTownScreenState extends State<AddHomeTownScreen> {
  final _controller = Get.find<ProfileController>();

  @override
  void initState() {
    super.initState();
    _controller.getCountry(search: 'in');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: Obx(
        () => CircleButtonWidget(
          icon: Icons.check,
          isEnable: _controller.isEnable.value,
          onTap: () {
            _controller.addHomeLocation(
              city: _controller.cityController.text,
              state: _controller.selectedState.value,
              country: _controller.selectedCountry.value,
            );
          },
        ),
      ),
      appBar: CustomAppBar(
        isCenterTitle: false,
        title: "Hometown",
        onTop: () {
          Get.back();
        },
      ),
      body: Padding(
        padding: 15.horizontalPadding,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            20.hBox,
            CommonText.text(
              "Where are you from?",
              fontSize: 20.sp,
              fontWeight: FontWeight.w500,
              fontFamily: "Caros",
            ),
            20.hBox,
            CommonText.text("Country"),
            10.hBox,
            InkWell(
              onTap: () async {
                await _controller.getCountry();
                final result = await Get.to(
                  () => LocationSearchScreen(
                    title: "Select Country",
                    type: 'country',
                    selectedValue: _controller.selectedCountry.value,
                  ),
                );
                if (result != null) {
                  _controller.selectedCountry.value = result;
                  _controller.selectedState.value = '';
                  _controller.cityController.clear();
                  await _controller.getState(country: result.toLowerCase());
                }
              },
              child: Obx(
                () => Container(
                  padding: 15.horizontalPadding,
                  alignment: Alignment.centerLeft,
                  width: MediaQuery.of(context).size.width,
                  height: 48.h,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20.r),
                    border: Border.all(
                      width: 2,
                      color:
                          _controller.selectedCountry.isNotEmpty
                              ? AppColors.textFieldColor
                              : AppColors.blackColor.withAlpha(64),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CommonText.text(
                        _controller.selectedCountry.value.isNotEmpty
                            ? _controller.selectedCountry.value
                            : "Select your country",
                      ),
                      Icon(Icons.keyboard_arrow_down),
                    ],
                  ),
                ),
              ),
            ),
            20.hBox,
            CommonText.text("State"),
            10.hBox,
            InkWell(
              onTap: () async {
                if (_controller.selectedCountry.isEmpty) return;
                final result = await Get.to(
                  () => LocationSearchScreen(
                    title: "Select State",
                    type: 'state',
                    country: _controller.selectedCountry.value.toLowerCase(),
                    selectedValue: _controller.selectedState.value,
                  ),
                );
                if (result != null) {
                  _controller.selectedState.value = result;
                  _controller.cityController.clear();
                  await _controller.getCity(
                    country: _controller.selectedCountry.value.toLowerCase(),
                    state: result.toLowerCase(),
                  );
                }
              },
              child: Obx(
                () => Container(
                  padding: 15.horizontalPadding,
                  alignment: Alignment.centerLeft,
                  width: MediaQuery.of(context).size.width,
                  height: 48.h,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20.r),
                    border: Border.all(
                      width: 2,
                      color:
                          _controller.selectedState.isNotEmpty
                              ? AppColors.textFieldColor
                              : AppColors.blackColor.withAlpha(64),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CommonText.text(
                        _controller.selectedState.value.isNotEmpty
                            ? _controller.selectedState.value
                            : "Select your state",
                      ),
                      Icon(Icons.keyboard_arrow_down),
                    ],
                  ),
                ),
              ),
            ),
            20.hBox,
            CommonText.text("City"),
            10.hBox,
            GestureDetector(
              onTap: () async {
                if (_controller.selectedState.isEmpty) return;
                final result = await Get.to(
                  () => LocationSearchScreen(
                    title: "Select City",
                    type: 'city',
                    country: _controller.selectedCountry.value.toLowerCase(),
                    state: _controller.selectedState.value.toLowerCase(),
                    selectedValue: _controller.cityController.text,
                  ),
                );
                if (result != null) {
                  _controller.cityController.text = result;
                  _controller.isEnable.value = true;
                }
              },
              child: AbsorbPointer(
                child: CustomFormField(
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z ]')),
                  ],
                  label: "",
                  hint: "Enter your city name",
                  controller: _controller.cityController,
                  enableBorder: _controller.isEnable,
                  suffixIcon: Icon(Icons.keyboard_arrow_down),
                  onChanged: (v) {
                    if (v != null && v.isNotEmpty) {
                      _controller.isEnable.value = true;
                      _controller.cityController.text = v;
                    } else {
                      _controller.isEnable.value = false;
                    }
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
