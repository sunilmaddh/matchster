class CommonMixin {}
