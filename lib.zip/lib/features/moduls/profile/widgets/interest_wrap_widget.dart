import 'package:flutter/material.dart';
import 'package:matchster/core/constants/app_colors.dart';
import 'package:matchster/core/extentions/interests_enum_ext.dart';
import 'package:matchster/core/utils/app_methods.dart';
import 'package:matchster/core/utils/extentions.dart';
import 'package:matchster/core/widgets/fields/common_text.dart';
import 'package:matchster/features/moduls/profile/widgets/common_wrap_widget.dart';
import 'package:matchster/features/moduls/profile/widgets/sub_common_card.dart';

class InterestWrapWidget extends StatelessWidget {
  const InterestWrapWidget({super.key, required this.list});
  final List<String> list;

  @override
  Widget build(BuildContext context) {
    list
        .map((e) => InterestEnumX.fromString(e)?.label)
        .whereType<String>()
        .toList();
    return CommonWrapWidget(
      listWidget:
          list.map((v) {
            final interest = InterestEnumX.fromString(v);
            return SubCommonCard(
              widget: CommonText.text(
                interest?.label ?? AppMethods.capitalizeFirst(v),
                color: AppColors.blackColor,
                fontSize: 14.sp,
                fontWeight: FontWeight.w500,
                fontFamily: "Caros",
              ),
            );
          }).toList(),
    );
  }
}
